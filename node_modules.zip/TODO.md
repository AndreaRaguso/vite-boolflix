
-- Implementare cerca un attore 1.30
-- Migliorare Login page con implementazione price e login domani
-- @keyup 30 domani
-- Fare Milestone 5 e 6 domani


Home Netflix

movie

-- Prossimi Arrivi (uncoming)
-- Più votati (top rated)
-- Più popalari (popular)
-- Ultimo uscito (latest)

serie 

-- Più votati (top rated)
-- Più popalari (popular)
-- Ultimo uscito (latest)

